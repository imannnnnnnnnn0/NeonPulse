
package com.neonpulse.player;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean pageReady = false;
    private boolean permissionAsked = false;

    private String audioPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return Manifest.permission.READ_MEDIA_AUDIO;
        }
        return Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean hasAudioPermission() {
        return Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(audioPermission()) ==
            PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void requestSongs() {
                runOnUiThread(() -> {
                    if (!hasAudioPermission()) {
                        if (!permissionAsked) {
                            permissionAsked = true;
                            if (Build.VERSION.SDK_INT >= 23) {
                                requestPermissions(
                                    new String[]{audioPermission()}, 200
                                );
                            }
                        }
                    } else {
                        sendSongsToPage();
                    }
                });
            }
        }, "AndroidMusic");

        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void sendSongsToPage() {
        if (!pageReady || !hasAudioPermission()) return;

        JSONArray songs = new JSONArray();

        String[] projection = {
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        };

        String selection =
            MediaStore.Audio.Media.IS_MUSIC + " != 0";

        try (Cursor cursor = getContentResolver().query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            MediaStore.Audio.Media.TITLE + " ASC"
        )) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media._ID);
                int titleCol = cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media.TITLE);
                int artistCol = cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media.ARTIST);

                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    String title = cursor.getString(titleCol);
                    String artist = cursor.getString(artistCol);

                    Uri uri = Uri.withAppendedPath(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        String.valueOf(id)
                    );

                    JSONObject song = new JSONObject();
                    song.put("name", title == null ? "آهنگ ناشناس" : title);
                    song.put("artist", artist == null ? "" : artist);
                    song.put("uri", uri.toString());
                    songs.put(song);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String json = songs.toString();
        String script = "window.onNativeSongs && window.onNativeSongs("
            + JSONObject.quote(json) + ");";

        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    @Override
    public void onRequestPermissionsResult(
        int requestCode, String[] permissions, int[] grantResults
    ) {
        super.onRequestPermissionsResult(
            requestCode, permissions, grantResults);

        if (requestCode == 200) {
            if (grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSongsToPage();
            } else {
                webView.post(() -> webView.evaluateJavascript(
                    "window.onMusicPermissionDenied && " +
                    "window.onMusicPermissionDenied();", null));
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (webView != null && hasAudioPermission()) {
            sendSongsToPage();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidMusic");
            webView.destroy();
        }
        super.onDestroy();
    }
}
