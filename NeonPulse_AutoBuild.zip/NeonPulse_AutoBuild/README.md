# NEON PULSE Android

A small Persian RTL neon music player built with Android WebView.

## Build APK
The GitHub Actions workflow `.github/workflows/build.yml` builds a debug APK on pushes to `main` or when manually run.

After the workflow succeeds: open the repository's **Actions** tab, select **Build NeonPulse APK**, open the successful run, and download the `NeonPulse-debug-apk` artifact. The downloaded artifact is a ZIP containing `app-debug.apk`.

This is a debug APK, not a Play Store release. It is unsigned for Play Store distribution but can normally be installed for personal testing after allowing installs from the browser/files app.
